
import { GoogleGenAI, Type } from "@google/genai";
import { Headline } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateHeadlines(): Promise<Headline[]> {
  const prompt = `Generate exactly 4 news headlines in Italian for a "Fake News Roulette" game. 
  Exactly THREE headlines must be TRUE (verifiable facts, unusual but real).
  Exactly ONE headline must be FAKE (extremely plausible misinformation, subtle distortions of reality, or sophisticated urban legends).
  
  CRITICAL: The fake news should NOT be obvious. It should sound like a real piece of news from science, tech, or international politics. Avoid obvious parodies or absurd humor.
  
  Return them as a JSON array of objects with "text" and "isTrue" properties. 
  The headlines should be punchy and formatted for a 2D game UI.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              text: { type: Type.STRING },
              isTrue: { type: Type.BOOLEAN }
            },
            required: ["text", "isTrue"]
          }
        }
      }
    });

    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr) as Headline[];
  } catch (error) {
    console.error("Failed to generate headlines:", error);
    // Fallback static headlines if API fails
    return [
      { text: "La Svezia ha rimosso ufficialmente l'uso del contante dal 2023.", isTrue: false },
      { text: "Il cuore di una balena azzurra è grande quanto un'auto.", isTrue: true },
      { text: "Le lune di Marte si stanno lentamente allontanando dal pianeta.", isTrue: true },
      { text: "L'Estonia è stato il primo paese al mondo a permettere il voto digitale.", isTrue: true }
    ];
  }
}
