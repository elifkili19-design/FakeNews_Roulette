
import React from 'react';

export const PixelArtShotgun: React.FC<{ orientation: 'left' | 'right', firing?: boolean }> = ({ orientation, firing }) => {
  return (
    <div className={`relative transition-all duration-300 ${firing ? 'shake' : ''} ${orientation === 'left' ? 'scale-x-[-1]' : ''}`}>
      <svg width="160" height="120" viewBox="0 0 160 120" className="drop-shadow-2xl">
        {/* Frame / Grip */}
        <rect x="25" y="45" width="45" height="65" fill="#1a1a1a" /> {/* Grip main */}
        <rect x="20" y="50" width="10" height="55" fill="#121212" /> {/* Grip back texture */}
        
        {/* Slide */}
        <rect x="25" y="25" width="125" height="30" fill="#2d2d2d" /> {/* Slide main */}
        <rect x="25" y="25" width="125" height="4" fill="#3d3d3d" /> {/* Slide top edge */}
        <rect x="25" y="45" width="115" height="10" fill="#222222" /> {/* Slide bottom detail */}
        
        {/* Sights */}
        <rect x="30" y="20" width="8" height="5" fill="#1a1a1a" /> {/* Rear sight */}
        <rect x="135" y="20" width="5" height="5" fill="#1a1a1a" /> {/* Front sight */}
        
        {/* Serrations on slide */}
        <rect x="35" y="32" width="2" height="15" fill="#1a1a1a" />
        <rect x="40" y="32" width="2" height="15" fill="#1a1a1a" />
        <rect x="45" y="32" width="2" height="15" fill="#1a1a1a" />
        <rect x="50" y="32" width="2" height="15" fill="#1a1a1a" />
        
        {/* Trigger Guard and Trigger */}
        <rect x="70" y="55" width="35" height="5" fill="#1a1a1a" /> {/* Bottom of guard */}
        <rect x="100" y="55" width="5" height="20" fill="#1a1a1a" /> {/* Front of guard */}
        <path d="M 75 55 L 75 75 L 85 75" stroke="#1a1a1a" strokeWidth="4" fill="none" /> {/* Trigger shape */}
        
        {/* Barrel / Muzzle */}
        <rect x="145" y="30" width="10" height="15" fill="#121212" />
        
        {/* Flash Effect */}
        {firing && (
          <g transform="translate(150, 20)">
            <circle cx="15" cy="15" r="12" fill="#FFD54F" opacity="0.9" />
            <circle cx="25" cy="15" r="18" fill="#FF9800" opacity="0.7" />
            <circle cx="35" cy="15" r="24" fill="#F44336" opacity="0.5" />
            
            {/* Rays */}
            <line x1="15" y1="15" x2="45" y2="15" stroke="#FFF" strokeWidth="4" />
            <line x1="15" y1="15" x2="40" y2="0" stroke="#FFF" strokeWidth="2" />
            <line x1="15" y1="15" x2="40" y2="30" stroke="#FFF" strokeWidth="2" />
          </g>
        )}
      </svg>
    </div>
  );
};
