
import React from 'react';
import { Headline } from '../types';

interface Props {
  headline: Headline;
  onClick: () => void;
  disabled: boolean;
  selected?: boolean;
}

export const HeadlineOption: React.FC<Props> = ({ headline, onClick, disabled, selected }) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        w-full p-6 text-left transition-all duration-200 pixel-border
        ${disabled ? 'opacity-30 grayscale pointer-events-none' : 'hover:bg-zinc-800 active:scale-[0.98]'}
        ${selected ? 'bg-red-900/20 border-red-500' : 'bg-black/40 border-zinc-800'}
        flex items-center gap-6 group relative overflow-hidden
      `}
    >
      <div className="absolute top-0 left-0 w-1 h-full bg-zinc-800 group-hover:bg-white transition-colors" />
      <span className="text-xl leading-relaxed uppercase tracking-widest text-zinc-300 group-hover:text-white ui-pixel">
        {headline.text}
      </span>
    </button>
  );
};
