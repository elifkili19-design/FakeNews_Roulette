
import React from 'react';

interface Props {
  damaged: boolean;
  lowHealth: boolean;
  phase: string;
}

export const Dealer: React.FC<Props> = ({ damaged, lowHealth, phase }) => {
  // Using the provided portrait. In a real environment, this would be a local asset path.
  // We'll use the image description provided as a conceptual reference.
  const imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/129.png"; // Placeholder
  // Since I can't upload the user's specific image, I'll use a stylized container that represents him
  // but the user should place their 'dealer.png' here.
  
  return (
    <div className={`relative transition-all duration-500 
      ${damaged ? 'hit-flash shake-intense' : 'breathing'}
      ${phase === 'CHOOSING_HEADLINE' ? 'opacity-100' : 'opacity-80 scale-95'}
      w-full max-w-lg mx-auto`}>
      
      {/* Dynamic shadow */}
      <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 w-3/4 h-10 bg-black/40 blur-2xl rounded-full" />
      
      {/* Character Image Container */}
      <div className="relative z-10 overflow-hidden">
        {/* We'll use the nervous man's data if possible, otherwise a high-quality placeholder for visual testing */}
        <img 
          src="https://images.squarespace-cdn.com/content/v1/5c98d41e77889728867a6d85/1589414902263-L3Z00Q6U09K0S5U4H8Z8/Character+Portrait+Nervous.png" 
          alt="The Dealer"
          className="w-full h-auto drop-shadow-[0_20px_50px_rgba(0,0,0,0.8)]"
          style={{ imageRendering: 'pixelated' }}
        />

        {/* Sweat / Nervous artifacts overlay */}
        {lowHealth && (
          <div className="absolute inset-0 bg-red-900/10 pointer-events-none animate-pulse" />
        )}
      </div>

      {/* Industrial Frame */}
      <div className="absolute inset-0 border-8 border-transparent pointer-events-none">
        <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-zinc-700" />
        <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-zinc-700" />
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-zinc-700" />
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-zinc-700" />
      </div>
    </div>
  );
};
